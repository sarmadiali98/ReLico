package org.rebecalang.compiler.modelcompiler.linguafranca;

import org.rebecalang.compiler.modelcompiler.corerebeca.objectmodel.*;
import org.rebecalang.compiler.modelcompiler.timedrebeca.objectmodel.TimedRebecaParentSuffixPrimary;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates Lingua Franca code from a Rebeca (or Timed Rebeca) model.
 */
public class LinguaFrancaCodeGenerator {

    /** The entire Rebeca model. */
    private final RebecaModel rebecaModel;

    /** A list of all reactive classes in the model. */
    private List<ReactiveClassDeclaration> classes;

    /** Stores environment variables (global definitions) from the model. */
    private final Map<String, String> envVariables = new HashMap<>();
    /** Special keys used inside parameter-mapping contexts for sender translation. */
    private static final String SENDER_INSTANCE_KEY = "__relico_sender_instance__";
    private static final String RECEIVER_INSTANCE_KEY = "__relico_receiver_instance__";
    private static final String KNOWN_REBEC_INSTANCE_PREFIX = "__relico_known_rebec_instance__:";


    /* ----------------------------------------------------------------------
     * Nested Data Classes
     * ----------------------------------------------------------------------
     */

    /** Represents constructor-related information for a reactive class. */
    private static class ConstructorInfo {
        List<ConstructorParam> params = new ArrayList<>();
        List<StateVar> regularStateVars = new ArrayList<>();
        Map<String, List<FormalParameterDeclaration>> msgsrvToParams = new HashMap<>();
        Map<String, List<FormalParameterDeclaration>> externalMsgsrvsToParams = new HashMap<>();
        // ========== ADD THESE TWO NEW FIELDS ==========
        Map<String, String> paramToStateMapping = new HashMap<>();
        List<Statement> constructorBodyStatements = new ArrayList<>();
        // ==============================================
    }

    /** Defines a constructor parameter and its corresponding state variable. */
    private static class ConstructorParam {
        String paramName;
        String stateVarName;
        String type;
        String defaultValue;
    }

    /** Represents a normal (non-constructor) state variable. */
    private static class StateVar {
        String name;
        String type;
    }

    /**
     * A call to a message server method, either internal (self.msgSrv(...))
     * or external (knownRebec.msgSrv(...)).
     */
    private static class CallDetail {
        final String msgName;
        final boolean isInternal;
        final String externalTargetInstance;
        String callerMsgsrvName;
        List<Expression> arguments = new ArrayList<>();
        String calleeClass;
        String afterDelayMs;

        CallDetail(String msgName, boolean isInternal, String externalTargetInstance) {
            this.msgName = msgName;
            this.isInternal = isInternal;
            this.externalTargetInstance = externalTargetInstance;
        }
    }

    /** Holds lines of code for a reaction body, plus sets of actions/ports used. */
    private static class ReactionContent {
        String code = "";
        Set<String> scheduledActions = new LinkedHashSet<>();
        Set<String> usedPorts = new LinkedHashSet<>();
    }

    /** A generated LF reaction plus the ordering metadata used for declaration order. */
    private static class GeneratedReaction {
        final String trigger;
        final ReactionContent content;
        final int priority;
        final int declarationIndex;

        GeneratedReaction(String trigger, ReactionContent content, int priority, int declarationIndex) {
            this.trigger = trigger;
            this.content = content;
            this.priority = priority;
            this.declarationIndex = declarationIndex;
        }
    }

    /* ----------------------------------------------------------------------
     * Constructor
     * ----------------------------------------------------------------------
     */

    /**
     * Constructs a code generator for a given Rebeca model.
     *
     * @param rebecaModel The input Rebeca model.
     */
    public LinguaFrancaCodeGenerator(RebecaModel rebecaModel) {
        this.rebecaModel = rebecaModel;
    }


    /* ----------------------------------------------------------------------
     * Public Entry Method
     * ----------------------------------------------------------------------
     */

    /**
     * Main method for generating the Lingua Franca code and writing it to a file.
     *
     * @param outputPath The path of the output .lf file.
     */
    public void generateCode(String outputPath) {
        StringBuilder lfCode = new StringBuilder();
        lfCode.append("target Cpp;\n\n");

        // 1) Gather environment variables
        if (rebecaModel.getRebecaCode().getEnvironmentVariables() != null) {
            for (FieldDeclaration fd : rebecaModel.getRebecaCode().getEnvironmentVariables()) {
                for (VariableDeclarator vd : fd.getVariableDeclarators()) {

                    String varName = vd.getVariableName();
                    String literalValue = null;
                    org.rebecalang.compiler.modelcompiler.corerebeca.objectmodel.VariableInitializer initializer = vd.getVariableInitializer();

                    if (initializer instanceof org.rebecalang.compiler.modelcompiler.corerebeca.objectmodel.OrdinaryVariableInitializer oval) {
                        Expression exprValue = oval.getValue();
                        String lfType = mapRebecaTypeToLF(fd.getType().getTypeName());
                        literalValue = expressionToString(exprValue, lfType, getDefaultValueForType(lfType));
                    } else if ("Literal".equals(initializer != null ? initializer.getClass().getSimpleName() : "")) {
                        // Attempt to get literal value directly, avoiding reflection
                        java.lang.reflect.Method getLiteralValueMethod = Arrays.stream(initializer.getClass().getMethods())
                                .filter(m -> m.getName().equals("getLiteralValue"))
                                .findFirst()
                                .orElse(null);

                        literalValue = (getLiteralValueMethod != null) ? initializer.toString() : null;
                    } else if (initializer != null) {
                        literalValue = initializer.toString();
                    }

                    if (literalValue == null) {
                        String lfType = mapRebecaTypeToLF(fd.getType().getTypeName());
                        literalValue = getDefaultValueForType(lfType);
                    }

                    envVariables.put(varName, literalValue);
                }
            }
        }


        // 2) Gather classes
        classes = rebecaModel.getRebecaCode().getReactiveClassDeclaration();

        // 3) Build constructor info
        Map<String, ConstructorInfo> constructorInfoMap = new HashMap<>();
        for (ReactiveClassDeclaration rc : classes) {
            ConstructorInfo cInfo = buildConstructorInfo(rc);
            constructorInfoMap.put(rc.getName(), cInfo);
        }

        // 4) Classify which msgSrvs are internal vs external
        Map<String, Set<String>> internalMsgsrvs = findInternalMsgServers(constructorInfoMap);

        // 5) Build instance->class map and known rebec info
        Map<String, String> instanceToClass = buildInstanceToClassMap();
        Map<String, List<String>> classToKnownRebecs = buildClassToKnownRebecsMap();
        Map<String, List<String>> instanceKnownRebecs = buildInstanceKnownRebecsMap(instanceToClass);

        // 6) Analyze all calls
        Map<String, List<CallDetail>> callsByInstance = new HashMap<>();
        for (String inst : instanceToClass.keySet()) {
            callsByInstance.put(inst, new ArrayList<>());
        }
        analyzeAllCalls(instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs);

        // 7) Generate struct definitions for message payloads.
        // External parameterized sends use typed ports.
        // Internal self-calls with more than one parameter use typed logical-action payload structs.
        lfCode.append("public preamble {=\n");
        Set<String> emittedStructs = new LinkedHashSet<>();

        for (ReactiveClassDeclaration rc : classes) {
            String className = rc.getName();
            ConstructorInfo cInfo = constructorInfoMap.get(className);
            Set<String> internalServers = internalMsgsrvs.getOrDefault(className, Collections.emptySet());

            for (String msgsrvName : cInfo.msgsrvToParams.keySet()) {
                if (msgsrvName.startsWith("constructorOf")) {
                    continue;
                }

                List<FormalParameterDeclaration> params =
                        cInfo.msgsrvToParams.getOrDefault(msgsrvName, Collections.emptyList());

                boolean isUsedExternally =
                        isMsgsrvExternallyUsed(msgsrvName, className, callsByInstance, instanceToClass);

                boolean needsInternalPayloadStruct =
                        internalServers.contains(msgsrvName) && params.size() > 1;

                if (isUsedExternally || needsInternalPayloadStruct) {
                    String structName = className + "_" + msgsrvName;

                    if (emittedStructs.add(structName)) {
                        lfCode.append("    struct ")
                                .append(structName)
                                .append(" {\n");

                        if (params.isEmpty()) {
                            lfCode.append("        int default_arg;\n");
                        } else {
                            for (FormalParameterDeclaration p : params) {
                                lfCode.append("        ")
                                        .append(mapRebecaTypeToLF(p.getType().getTypeName()))
                                        .append(" ")
                                        .append(p.getName())
                                        .append(";\n");
                            }
                        }

                        lfCode.append("    };\n");
                    }
                }
            }
        }

        lfCode.append("=}\n\n");

        Map<String, Set<String>> unusedMsgsrvs = findUnusedMsgServers(
                internalMsgsrvs,
                callsByInstance,
                instanceToClass
        );

        // 8) Generate one reactor per Rebeca class
        for (ReactiveClassDeclaration rc : classes) {
            String className = rc.getName();
            ConstructorInfo cInfo = constructorInfoMap.get(className);

            lfCode.append("reactor ").append(className);

            // If constructor has parameters => make them reactor parameters
            if (!cInfo.params.isEmpty()) {
                lfCode.append("(");
                for (int i = 0; i < cInfo.params.size(); i++) {
                    if (i > 0) {
                        lfCode.append(", ");
                    }
                    ConstructorParam cp = cInfo.params.get(i);
                    lfCode.append(cp.stateVarName)
                            .append(": ")
                            .append(cp.type)
                            .append(" = ")
                            .append(cp.defaultValue);
                }
                lfCode.append(")");
            }
            lfCode.append(" {\n");

            // A) Create I/O ports for external calls
            Set<String> declaredPorts = new LinkedHashSet<>();

            // (a) Outputs: calls made by any instance of this class
            for (Map.Entry<String, List<CallDetail>> entry : callsByInstance.entrySet()) {
                String callerInstance = entry.getKey();
                String callerClass = instanceToClass.get(callerInstance);
                if (!callerClass.equals(className)) {
                    continue;
                }

                for (CallDetail cd : entry.getValue()) {
                    if (!cd.isInternal) {
                        String calleeInst = cd.externalTargetInstance;
                        String outPortName = cd.msgName + "_to_" + calleeInst + "_from_" + callerInstance + "_out";
                        if (!declaredPorts.contains(outPortName)) {
                            declaredPorts.add(outPortName);
                            String calleeClass = instanceToClass.get(calleeInst);
                            List<FormalParameterDeclaration> fps = constructorInfoMap
                                    .get(calleeClass)
                                    .msgsrvToParams
                                    .getOrDefault(cd.msgName, Collections.emptyList());
                            String lfType = (fps.isEmpty()) ? "int" : (calleeClass + "_" + cd.msgName);
                            lfCode.append("    output ").append(outPortName).append(": ").append(lfType).append(";\n");
                        }
                    }
                }
            }

            // (b) Inputs: calls received by this class's instances
            Map<String, Set<String>> inputsByMsgsrv = new HashMap<>();
            for (List<CallDetail> callList : callsByInstance.values()) {
                for (CallDetail cd : callList) {
                    if (!cd.isInternal && instanceToClass.get(cd.externalTargetInstance).equals(className)) {
                        String callerInst = findCallerInstanceFor(cd, callsByInstance);
                        if (callerInst == null) {
                            callerInst = "unknownCaller";
                        }
                        String portName = cd.msgName + "_to_" + cd.externalTargetInstance
                                + "_from_" + callerInst + "_in";

                        if (!declaredPorts.contains(portName)) {
                            declaredPorts.add(portName);
                            List<FormalParameterDeclaration> fps = cInfo.msgsrvToParams
                                    .getOrDefault(cd.msgName, Collections.emptyList());
                            String lfType = (fps.isEmpty()) ? "int" : (className + "_" + cd.msgName);
                            lfCode.append("    input ").append(portName).append(": ").append(lfType).append(";\n");
                        }
                        inputsByMsgsrv.computeIfAbsent(cd.msgName, k -> new LinkedHashSet<>())
                                .add(portName);
                    }
                }
            }

            // B) State variables
            for (StateVar sv : cInfo.regularStateVars) {
                lfCode.append("    state ")
                        .append(sv.name)
                        .append(": ")
                        .append(sv.type)
                        .append("\n");
            }

            Set<String> internalServers = internalMsgsrvs.getOrDefault(className, Collections.emptySet());

            // C) Logical actions for internal msgSrvs.
            // Parameterless internal msgSrvs use untyped logical actions.
            // Parameterized internal msgSrvs use typed logical actions whose payload carries the arguments.
            for (String m : internalServers) {
                if (!m.startsWith("constructorOf")) {
                    MsgsrvDeclaration md = findMsgsrv(rc, m);
                    List<FormalParameterDeclaration> fps =
                            (md == null) ? Collections.emptyList() : md.getFormalParameters();

                    lfCode.append("    logical action ").append(m);

                    if (fps.size() == 1) {
                        lfCode.append(": ")
                                .append(mapRebecaTypeToLF(fps.get(0).getType().getTypeName()));
                    } else if (fps.size() > 1) {
                        lfCode.append(": ")
                                .append(className)
                                .append("_")
                                .append(m);
                    }

                    lfCode.append(";\n");
                }
            }

            // D) Reactions for message servers.
            // DTR local message-server priority is encoded by the textual order of
            // LF reactions inside the same reactor. Smaller @priority values are emitted earlier.
            List<GeneratedReaction> generatedReactions = new ArrayList<>();

            // D1) Internal msgSrvs => one reaction per logical action
            for (String m : internalServers) {
                if (m.startsWith("constructorOf")) {
                    continue;
                }

                ReactionContent rContent = generateMsgsrvReactionBody(
                        rc, m, className, cInfo, instanceToClass, callsByInstance
                );

                generatedReactions.add(new GeneratedReaction(
                        m,
                        rContent,
                        getMsgsrvPriority(rc, m),
                        getMsgsrvDeclarationIndex(rc, m)
                ));
            }

            // D2) External msgSrvs => one reaction per input port
            for (Map.Entry<String, Set<String>> entry : inputsByMsgsrv.entrySet()) {
                String externalMsgsrvName = entry.getKey();
                Set<String> portNames = entry.getValue();
                if (portNames.isEmpty()) {
                    continue;
                }

                MsgsrvDeclaration mDecl = findMsgsrv(rc, externalMsgsrvName);
                int priority = getMsgsrvPriority(rc, externalMsgsrvName);
                int declarationIndex = getMsgsrvDeclarationIndex(rc, externalMsgsrvName);

                for (String portName : portNames) {
                    ReactionContent rContent;
                    if (mDecl != null && mDecl.getBlock() != null) {
                        rContent = generateExternalMsgsrvReactionBody(
                                mDecl, portName, className, cInfo, instanceToClass, callsByInstance
                        );
                    } else {
                        rContent = new ReactionContent();
                    }

                    generatedReactions.add(new GeneratedReaction(
                            portName,
                            rContent,
                            priority,
                            declarationIndex
                    ));
                }
            }

            generatedReactions.sort(
                    Comparator.comparingInt((GeneratedReaction gr) -> gr.priority)
                            .thenComparingInt(gr -> gr.declarationIndex)
                            .thenComparing(gr -> gr.trigger)
            );

            for (GeneratedReaction gr : generatedReactions) {
                lfCode.append(renderReaction(gr.trigger, gr.content));
            }

            // D3) Commented stubs for unused msgSrvs
            Set<String> unusedServers = unusedMsgsrvs.getOrDefault(className, Collections.emptySet());
            if (!unusedServers.isEmpty()) {
                lfCode.append("\n");
                for (String m : unusedServers) {
                    MsgsrvDeclaration mDecl = findMsgsrv(rc, m);
                    if (mDecl != null) {
                        // Generate reaction body for documentation but no ports or live traces
                        ReactionContent rContent = generateUnusedMsgsrvReactionBody(
                                mDecl, className, cInfo, instanceToClass, callsByInstance
                        );

                        lfCode.append("    // Unused msgsrv: ").append(m).append("\n").append
                                ("    // This reaction is declared but never used\n").append
                                ("    // Since it is neither internal nor external, it's not triggered by a logical action or an input\n").append
                                ("    // This will cause a warning you can either safely ignore,\n").append
                                ("    // or remove the message server from your source Timed Rebeca code\n\n")
                        ;

                        if (!rContent.code.isEmpty()) {
                            lfCode.append("    reaction()");
                            if (!rContent.usedPorts.isEmpty()) {
                                lfCode.append(" -> ");
                                lfCode.append(String.join(", ", rContent.usedPorts));
                            }
                            lfCode.append(" {=\n");
                            lfCode.append(rContent.code);
                            lfCode.append("    =}\n");
                        }
                    }
                }
            }


            // E) If there's a constructor => reaction(startup)
            ConstructorDeclaration theConstructor = rc.getConstructors().isEmpty() ? null : rc.getConstructors().get(0);
            if (theConstructor != null) {
                ReactionContent rContent = generateConstructorReactionBody(
                        theConstructor.getBlock(),
                        className, cInfo, internalMsgsrvs,
                        instanceToClass, callsByInstance
                );
                if (!rContent.code.isEmpty()) {
                    lfCode.append("    reaction(startup)");
                    if (!rContent.scheduledActions.isEmpty() || !rContent.usedPorts.isEmpty()) {
                        lfCode.append(" -> ");
                        List<String> outputs = new ArrayList<>();
                        outputs.addAll(rContent.scheduledActions);
                        outputs.addAll(rContent.usedPorts);
                        for (int i = 0; i < outputs.size(); i++) {
                            if (i > 0) {
                                lfCode.append(", ");
                            }
                            lfCode.append(outputs.get(i));
                        }
                    }
                    lfCode.append(" {=\n");
                    lfCode.append(rContent.code);
                    lfCode.append("    =}\n");
                }
            }

            lfCode.append("}\n\n");
        }

        // 9) Main reactor
        MainDeclaration mainDecl = rebecaModel.getRebecaCode().getMainDeclaration();
        if (mainDecl != null) {
            lfCode.append("main reactor {\n");
            for (MainRebecDefinition md : mainDecl.getMainRebecDefinition()) {
                String instName = md.getName();
                String clsName = md.getType().getTypeName();
                ConstructorInfo cInfo = constructorInfoMap.get(clsName);

                lfCode.append("    ").append(instName)
                        .append(" = new ")
                        .append(clsName);

                List<Expression> cArgs = md.getArguments();
                if (!cInfo.params.isEmpty()) {
                    lfCode.append("(");
                    for (int i = 0; i < cInfo.params.size(); i++) {
                        if (i > 0) {
                            lfCode.append(", ");
                        }
                        ConstructorParam cp = cInfo.params.get(i);
                        String paramVal = cp.defaultValue;
                        if (cArgs != null && i < cArgs.size()) {
                            paramVal = expressionToString(cArgs.get(i), cp.type, cp.defaultValue);
                        }
                        lfCode.append(cp.stateVarName).append(" = ").append(paramVal);
                    }
                    lfCode.append(")");
                } else {
                    lfCode.append("()");
                }
                lfCode.append(";\n");
            }
            lfCode.append(generateConnectionStatements(callsByInstance, instanceToClass));
            lfCode.append("}\n\n");
        }

        // 10) POST-PROCESSING: Eliminate duplicate .set() and .schedule() calls
        String generatedCode = lfCode.toString();
        SimpleBroadcastEliminator eliminator = new SimpleBroadcastEliminator();
        String cleanedCode = eliminator.eliminateDuplicates(generatedCode);

        // 11) Write to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            writer.write(cleanedCode);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Optional: debug structure
        analyzeAndPrintStructureMap();
    }


    /* ----------------------------------------------------------------------
     * Debug / Structure Analysis
     * ----------------------------------------------------------------------
     */

    /**
     * Analyzes and prints a structure map for debugging (optional).
     */
    private void analyzeAndPrintStructureMap() {
        Map<String, String> instanceToClass = buildInstanceToClassMap();
        Map<String, List<String>> instanceKnownRebecs = buildInstanceKnownRebecsMap(instanceToClass);
        Map<String, Set<String>> classToMsgServers = collectMessageServers();

        Map<String, List<CallDetail>> callsByInstance = new HashMap<>();
        for (String inst : instanceToClass.keySet()) {
            callsByInstance.put(inst, new ArrayList<>());
        }

        Map<String, List<String>> classToKnownRebecs = buildClassToKnownRebecsMap();
        Map<String, List<String>> instanceKnownRebecs_ = buildInstanceKnownRebecsMap(instanceToClass);

        analyzeAllCalls(instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs_);
        printStructureMap(instanceToClass, instanceKnownRebecs, classToMsgServers, callsByInstance);
    }

    /**
     * Collects all message servers (including constructors) declared by each class.
     */
    private Map<String, Set<String>> collectMessageServers() {
        Map<String, Set<String>> result = new HashMap<>();
        for (ReactiveClassDeclaration rc : classes) {
            Set<String> ms = new HashSet<>();
            if (!rc.getConstructors().isEmpty()) {
                ms.add("constructorOf" + rc.getName());
            }
            for (MsgsrvDeclaration m : rc.getMsgsrvs()) {
                ms.add(m.getName());
            }
            for (MethodDeclaration md : rc.getSynchMethods()) {
                ms.add(md.getName());
            }
            result.put(rc.getName(), ms);
        }
        return result;
    }

    /**
     * Prints a high-level structure map of rebecs, known rebecs, and calls made.
     */
    private void printStructureMap(
            Map<String, String> instanceToClass,
            Map<String, List<String>> instanceKnownRebecs,
            Map<String, Set<String>> classToMsgServers,
            Map<String, List<CallDetail>> callsByInstance
    ) {
        System.out.println("=== Rebeca Structure Map ===\n");
        System.out.println("1) Rebecs and their known rebecs:");
        for (String inst : instanceToClass.keySet()) {
            String cls = instanceToClass.get(inst);
            List<String> known = instanceKnownRebecs.getOrDefault(inst, Collections.emptyList());
            System.out.printf("   - %s (Reactive Class: %s) knows: %s\n", inst, cls, known);
        }

        Map<String, List<String>> classToInstances = instanceToClass.entrySet().stream()
                .collect(Collectors.groupingBy(
                        Map.Entry::getValue,
                        Collectors.mapping(Map.Entry::getKey, Collectors.toList())
                ));

        System.out.println("\n2) Declared message servers and calls made by each rebec:");
        for (var cEntry : classToInstances.entrySet()) {
            String cls = cEntry.getKey();
            List<String> insts = cEntry.getValue();
            Set<String> declaredServers = classToMsgServers.getOrDefault(cls, Collections.emptySet());

            System.out.println("   Reactive Class: " + cls);
            for (String inst : insts) {
                System.out.println("      Instance: " + inst);
                for (String s : declaredServers) {
                    System.out.println("         Declares msgSrv: " + s);
                }
                List<CallDetail> callList = callsByInstance.getOrDefault(inst, Collections.emptyList());
                if (callList.isEmpty()) {
                    System.out.println("         (No calls made.)");
                } else {
                    Map<String, Integer> callTally = new HashMap<>();
                    for (CallDetail cd : callList) {
                        callTally.put(cd.msgName, callTally.getOrDefault(cd.msgName, 0) + 1);
                    }
                    System.out.println("         Calls made by " + inst + ":");
                    for (CallDetail cd : callList) {
                        if (cd.isInternal) {
                            System.out.printf("            -> INTERNAL call to %s()\n", cd.msgName);
                        } else {
                            System.out.printf("            -> EXTERNAL call to %s() in rebec '%s'\n",
                                    cd.msgName, cd.externalTargetInstance);
                        }
                    }
                    System.out.println("         Call counts:");
                    for (var c : callTally.entrySet()) {
                        System.out.printf("            %s: %d times\n", c.getKey(), c.getValue());
                    }
                }
            }
        }
    }


    /* ----------------------------------------------------------------------
     * Internal Helper Methods for Code Generation
     * ----------------------------------------------------------------------
     */

    /**
     * Determine which message servers are considered internal (called by self).
     */
    private Map<String, Set<String>> findInternalMsgServers(Map<String, ConstructorInfo> constructorInfoMap) {
        Map<String, Set<String>> internalMsgsrvs = new HashMap<>();
        for (ReactiveClassDeclaration rc : classes) {
            String cName = rc.getName();
            Set<String> internalCalls = new HashSet<>();

            for (ConstructorDeclaration cd : rc.getConstructors()) {
                analyzeBlockForInternalCalls(cd.getBlock(), cName, internalCalls);
            }
            for (MsgsrvDeclaration msgs : rc.getMsgsrvs()) {
                analyzeBlockForInternalCalls(msgs.getBlock(), cName, internalCalls);
            }
            for (MethodDeclaration md : rc.getSynchMethods()) {
                analyzeBlockForInternalCalls(md.getBlock(), cName, internalCalls);
            }

            Set<String> allMsgsrvs = new HashSet<>();
            if (!rc.getConstructors().isEmpty()) {
                allMsgsrvs.add("constructorOf" + cName);
            }
            for (MsgsrvDeclaration m : rc.getMsgsrvs()) {
                allMsgsrvs.add(m.getName());
            }
            for (MethodDeclaration syn : rc.getSynchMethods()) {
                allMsgsrvs.add(syn.getName());
            }

            Set<String> internalServerNames = new HashSet<>();
            for (String m : allMsgsrvs) {
                boolean isConstructor = m.startsWith("constructorOf");
                if (internalCalls.contains(m) || isConstructor) {
                    internalServerNames.add(m);
                }
            }

            internalMsgsrvs.put(cName, internalServerNames);
        }
        return internalMsgsrvs;
    }

    /**
     * Find msgsrvs that are declared but never called (neither internally nor externally).
     */
    private Map<String, Set<String>> findUnusedMsgServers(
            Map<String, Set<String>> internalMsgsrvs,
            Map<String, List<CallDetail>> callsByInstance,
            Map<String, String> instanceToClass
    ) {
        Map<String, Set<String>> unusedMsgsrvs = new HashMap<>();

        for (ReactiveClassDeclaration rc : classes) {
            String className = rc.getName();
            Set<String> unused = new HashSet<>();

            // All declared msgsrvs of this class
            Set<String> allDeclared = new HashSet<>();
            for (MsgsrvDeclaration m : rc.getMsgsrvs()) {
                allDeclared.add(m.getName());
            }

            // Internal msgsrvs of this class
            Set<String> internals = internalMsgsrvs.getOrDefault(className, Collections.emptySet());

            // External msgsrvs of this class (called by other rebecs)
            Set<String> externals = new HashSet<>();
            for (List<CallDetail> callList : callsByInstance.values()) {
                for (CallDetail cd : callList) {
                    if (!cd.isInternal && cd.externalTargetInstance != null) {
                        String targetClass = instanceToClass.get(cd.externalTargetInstance);
                        if (className.equals(targetClass)) {
                            externals.add(cd.msgName);
                        }
                    }
                }
            }

            // Unused = declared but neither internal nor external
            for (String msgsrvName : allDeclared) {
                if (!internals.contains(msgsrvName) && !externals.contains(msgsrvName)) {
                    unused.add(msgsrvName);
                }
            }

            unusedMsgsrvs.put(className, unused);
        }

        return unusedMsgsrvs;
    }

    /**
     * Check if a msgSrv is actually used by some external caller.
     */
    private boolean isMsgsrvExternallyUsed(
            String msgsrvName,
            String className,
            Map<String, List<CallDetail>> callsByInstance,
            Map<String, String> instanceToClass
    ) {
        for (List<CallDetail> callList : callsByInstance.values()) {
            for (CallDetail cd : callList) {
                if (!cd.isInternal && cd.msgName.equals(msgsrvName)) {
                    String tgtCls = instanceToClass.get(cd.externalTargetInstance);
                    if (className.equals(tgtCls)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Generate the reaction content for an internal msgsrv.
     */
    private ReactionContent generateMsgsrvReactionBody(
            ReactiveClassDeclaration rc,
            String msgsrvName,
            String className,
            ConstructorInfo cInfo,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance
    ) {
        ReactionContent rContent = new ReactionContent();
        MsgsrvDeclaration found = findMsgsrv(rc, msgsrvName);
        if (found == null || found.getBlock() == null) {
            return rContent;
        }

        Map<String, String> internalParamMapping = new HashMap<>();
        List<FormalParameterDeclaration> fps =
                cInfo.msgsrvToParams.getOrDefault(msgsrvName, Collections.emptyList());

        String localParamDeclarations = buildLocalParamDeclarations(
                fps,
                msgsrvName,
                internalParamMapping,
                fp -> {
                    if (fps.size() == 1) {
                        return "(*" + msgsrvName + ".get())";
                    }
                    return "(*" + msgsrvName + ".get())." + fp.getName();
                }
        );

        String bodyCode = parseBlockStatementInline(
                found.getBlock(),
                className,
                msgsrvName,
                cInfo,
                instanceToClass,
                callsByInstance,
                rContent.scheduledActions,
                rContent.usedPorts,
                internalParamMapping
        );

        rContent.code = localParamDeclarations + bodyCode;
        return rContent;
    }

    /**
     * Create local variables for message-server parameters at the beginning of a reaction body.
     * This is necessary because DTR message-server parameters are mutable local variables,
     * while LF input/action payloads are immutable values accessed through get().
     */
    private String buildLocalParamDeclarations(
            List<FormalParameterDeclaration> fps,
            String msgsrvName,
            Map<String, String> paramMapping,
            java.util.function.Function<FormalParameterDeclaration, String> payloadAccessor
    ) {
        StringBuilder declarations = new StringBuilder();

        for (FormalParameterDeclaration fp : fps) {
            String lfType = mapRebecaTypeToLF(fp.getType().getTypeName());
            String localName = "relParam_" + msgsrvName + "_" + fp.getName();
            String accessor = payloadAccessor.apply(fp);

            paramMapping.put(fp.getName(), localName);

            declarations.append("        ")
                    .append(lfType)
                    .append(" ")
                    .append(localName)
                    .append(" = ")
                    .append(accessor)
                    .append(";\n");
        }

        return declarations.toString();
    }

    /**
     * Generate code for a constructor => reaction(startup).
     */
    private ReactionContent generateConstructorReactionBody(
            Statement constructorBody,
            String className,
            ConstructorInfo cInfo,
            Map<String, Set<String>> internalMsgsrvs,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance
    ) {
        ReactionContent rc = new ReactionContent();
        // Process only filtered statements from cInfo
        if (cInfo.constructorBodyStatements.isEmpty()) {
            return rc;
        }

        StringBuilder code = new StringBuilder();
        for (Statement stmt : cInfo.constructorBodyStatements) {
            String translated = parseBlockStatementInline(
                    stmt,              // Process each filtered statement
                    className,
                    "",
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    rc.scheduledActions,
                    rc.usedPorts,
                    null
            );
            code.append(translated);
        }
        rc.code = code.toString();
        return rc;
    }

    /**
     * Generate a reaction body for an external msgsrv triggered by some input port.
     */
    private ReactionContent generateExternalMsgsrvReactionBody(
            MsgsrvDeclaration externalMsgSrvDecl,
            String portName,
            String className,
            ConstructorInfo cInfo,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance
    ) {
        ReactionContent rc = new ReactionContent();
        if (externalMsgSrvDecl == null || externalMsgSrvDecl.getBlock() == null) {
            return rc;
        }

        Map<String, String> externalParamMapping = new HashMap<>();

        // Add sender context so conditions such as "sender == forkL" can be
        // reduced to true/false for this particular input-port reaction.
        externalParamMapping.putAll(
                buildSenderContextForExternalPort(className, portName, instanceToClass)
        );

        List<FormalParameterDeclaration> fps = cInfo.msgsrvToParams
                .getOrDefault(externalMsgSrvDecl.getName(), Collections.emptyList());

        String localParamDeclarations = buildLocalParamDeclarations(
                fps,
                externalMsgSrvDecl.getName(),
                externalParamMapping,
                fp -> "(*" + portName + ".get())." + fp.getName()
        );

        String bodyCode = parseBlockStatementInline(
                externalMsgSrvDecl.getBlock(),
                className,
                externalMsgSrvDecl.getName(),
                cInfo,
                instanceToClass,
                callsByInstance,
                rc.scheduledActions,
                rc.usedPorts,
                externalParamMapping
        );

        rc.code = localParamDeclarations + bodyCode;
        return rc;
    }

    /**
     * Convert Rebeca statements into lines of LF code for a reaction body (inline).
     */
    private String parseBlockStatementInline(
            Statement stmt,
            String className,
            String currentMsgsrvName,
            ConstructorInfo cInfo,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance,
            Set<String> scheduledActions,
            Set<String> usedPorts,
            Map<String, String> externalParamMapping
    ) {
        if (stmt == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();

        if (stmt instanceof BlockStatement bs) {
            for (Statement sub : bs.getStatements()) {
                sb.append(parseBlockStatementInline(
                        sub,
                        className,
                        currentMsgsrvName,
                        cInfo,
                        instanceToClass,
                        callsByInstance,
                        scheduledActions,
                        usedPorts,
                        externalParamMapping
                ));
            }
        } else if (stmt instanceof ConditionalStatement cs) {
            String condStr = transformExpression(cs.getCondition(), currentMsgsrvName, cInfo, externalParamMapping);
            sb.append("        if (").append(condStr).append(") {\n");
            sb.append(parseBlockStatementInline(
                    cs.getStatement(),
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));
            sb.append("        }");
            if (cs.getElseStatement() != null) {
                sb.append(" else {\n");
                sb.append(parseBlockStatementInline(
                        cs.getElseStatement(),
                        className,
                        currentMsgsrvName,
                        cInfo,
                        instanceToClass,
                        callsByInstance,
                        scheduledActions,
                        usedPorts,
                        externalParamMapping
                ));
                sb.append("        }");
            }
            sb.append("\n");
        } else if (stmt instanceof ForStatement fs) {
            String initPart = fs.getForInitializer().toString();
            String condStr = "";
            if (fs.getCondition() != null) {
                condStr = transformExpression(fs.getCondition(), currentMsgsrvName, cInfo, externalParamMapping);
            }
            String updatePart = fs.getForIncrement().toString();

            sb.append("        for (")
                    .append(initPart).append("; ")
                    .append(condStr).append("; ")
                    .append(updatePart).append(") {\n");
            sb.append(parseBlockStatementInline(
                    fs.getStatement(),
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));
            sb.append("        }\n");
        } else if (stmt instanceof WhileStatement ws) {
            String condStr = transformExpression(ws.getCondition(), currentMsgsrvName, cInfo, externalParamMapping);
            sb.append("        while (").append(condStr).append(") {\n");
            sb.append(parseBlockStatementInline(
                    ws.getStatement(),
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));
            sb.append("        }\n");
        } else if (stmt instanceof Expression expr) {
            sb.append(processExpressionInline(
                    expr,
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));
        } else {
            sb.append("        // Unhandled statement type: ")
                    .append(stmt.getClass().getSimpleName())
                    .append("\n");
        }
        return sb.toString();
    }

    /**
     * Process an expression statement in Rebeca and produce corresponding lines of LF code.
     */
    private String processExpressionInline(
            Expression expr,
            String className,
            String currentMsgsrvName,
            ConstructorInfo cInfo,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance,
            Set<String> scheduledActions,
            Set<String> usedPorts,
            Map<String, String> externalParamMapping
    ) {
        if (expr == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();

        if (expr instanceof BinaryExpression be) {
            String op = be.getOperator();

            if (isAssignmentOperator(op)) {
                String leftStr = transformExpression(be.getLeft(), currentMsgsrvName, cInfo, externalParamMapping);
                String rightStr = transformExpression(be.getRight(), currentMsgsrvName, cInfo, externalParamMapping);
                sb.append("        ")
                        .append(leftStr)
                        .append(" ")
                        .append(op)
                        .append(" ")
                        .append(rightStr)
                        .append(";\n");
            } else {
                // For non-assignment binary expressions, parse sub-expressions to detect calls.
                sb.append(processExpressionInline(
                        be.getLeft(),
                        className,
                        currentMsgsrvName,
                        cInfo,
                        instanceToClass,
                        callsByInstance,
                        scheduledActions,
                        usedPorts,
                        externalParamMapping
                ));
                sb.append(processExpressionInline(
                        be.getRight(),
                        className,
                        currentMsgsrvName,
                        cInfo,
                        instanceToClass,
                        callsByInstance,
                        scheduledActions,
                        usedPorts,
                        externalParamMapping
                ));
            }
        } else if (expr instanceof DotPrimary dot) {
            sb.append(processExpressionInline(
                    dot.getLeft(),
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));
            sb.append(processExpressionInline(
                    dot.getRight(),
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));

            if (dot.getRight() instanceof TermPrimary methodTerm) {
                String methodName = methodTerm.getName();
                ParentSuffixPrimary psp = methodTerm.getParentSuffixPrimary();
                List<Expression> argList = (psp == null) ? Collections.emptyList() : psp.getArguments();

                // INTERNAL call => self.method(...)
                if (dot.getLeft() instanceof TermPrimary leftTerm && "self".equals(leftTerm.getName())) {
                    for (Map.Entry<String, List<CallDetail>> e : callsByInstance.entrySet()) {
                        String callerInstance = e.getKey();
                        String callerClass = instanceToClass.get(callerInstance);
                        if (!callerClass.equals(className)) {
                            continue;
                        }
                        for (CallDetail cd : e.getValue()) {
                            if (cd.isInternal && cd.msgName.equals(methodName)
                                    && currentMsgsrvName.equals(cd.callerMsgsrvName)) {

                                List<FormalParameterDeclaration> fps =
                                        cInfo.msgsrvToParams.getOrDefault(methodName, Collections.emptyList());

                                List<String> payloadArgs = new ArrayList<>();
                                for (int i = 0; i < fps.size(); i++) {
                                    FormalParameterDeclaration fpd = fps.get(i);
                                    String paramVal = (i < argList.size())
                                            ? transformExpression(argList.get(i), currentMsgsrvName, cInfo, externalParamMapping)
                                            : getDefaultValueForType(mapRebecaTypeToLF(fpd.getType().getTypeName()));
                                    payloadArgs.add(paramVal);
                                }

                                String scheduleTime = (cd.afterDelayMs != null && !cd.afterDelayMs.isEmpty())
                                        ? cd.afterDelayMs + "ms"
                                        : "0ms";

                                sb.append("        ")
                                        .append(methodName)
                                        .append(".schedule(");

                                if (fps.size() == 0) {
                                    sb.append(scheduleTime);
                                } else if (fps.size() == 1) {
                                    sb.append(payloadArgs.get(0))
                                            .append(", ")
                                            .append(scheduleTime);
                                } else {
                                    String payloadType = className + "_" + methodName;
                                    sb.append(payloadType)
                                            .append("{")
                                            .append(String.join(", ", payloadArgs))
                                            .append("}, ")
                                            .append(scheduleTime);
                                }

                                sb.append(");\n");
                                scheduledActions.add(methodName);
                            }
                        }
                    }
                    // EXTERNAL call => knownRebec.method(...)
                } else if (dot.getLeft() instanceof TermPrimary knownField) {
                    for (Map.Entry<String, List<CallDetail>> e : callsByInstance.entrySet()) {
                        String callerInstance = e.getKey();
                        String callerClass = instanceToClass.get(callerInstance);
                        if (!callerClass.equals(className)) {
                            continue;
                        }
                        for (CallDetail cd : e.getValue()) {
                            if (!cd.isInternal && cd.msgName.equals(methodName)
                                    && currentMsgsrvName.equals(cd.callerMsgsrvName)) {
                                String outPort = methodName + "_to_"
                                        + cd.externalTargetInstance + "_from_"
                                        + callerInstance + "_out";
                                String calleeCls = cd.calleeClass;
                                List<FormalParameterDeclaration> fps = (calleeCls == null)
                                        ? Collections.emptyList()
                                        : cInfoFor(calleeCls, instanceToClass)
                                        .msgsrvToParams
                                        .getOrDefault(methodName, Collections.emptyList());

                                String structType = (fps.isEmpty()) ? "int" : (calleeCls + "_" + methodName);

                                StringBuilder structInit = new StringBuilder();
                                structInit.append(structType).append("{");
                                for (int i = 0; i < argList.size(); i++) {
                                    if (i > 0) {
                                        structInit.append(", ");
                                    }
                                    String exprStr = transformExpression(argList.get(i),
                                            currentMsgsrvName, cInfo, externalParamMapping);
                                    structInit.append(exprStr);
                                }
                                structInit.append("}");

                                sb.append("        ")
                                        .append(outPort)
                                        .append(".set(")
                                        .append(structInit)
                                        .append(");\n");
                                usedPorts.add(outPort);
                            }
                        }
                    }
                }
            }
        } else if (expr instanceof UnaryExpression ue) {
            sb.append(processExpressionInline(
                    ue.getExpression(),
                    className,
                    currentMsgsrvName,
                    cInfo,
                    instanceToClass,
                    callsByInstance,
                    scheduledActions,
                    usedPorts,
                    externalParamMapping
            ));
        } else if (expr instanceof Literal) {
            // no-op for direct literal usage
        } else if (expr instanceof TermPrimary) {
            // no-op for simple variable references without assignment/calls
        }
        return sb.toString();
    }

    /**
     * Returns true for assignment and compound-assignment operators that should
     * be emitted as standalone statements in LF/C++ reaction bodies.
     */
    private boolean isAssignmentOperator(String op) {
        return "=".equals(op)
                || "+=".equals(op)
                || "-=".equals(op)
                || "*=".equals(op)
                || "/=".equals(op)
                || "%=".equals(op)
                || "&=".equals(op)
                || "|=".equals(op)
                || "^=".equals(op)
                || "<<=".equals(op)
                || ">>=".equals(op);
    }

    /**
     * Locate the instance name that made this CallDetail, if any.
     */
    private String findCallerInstanceFor(CallDetail cd, Map<String, List<CallDetail>> callsByInstance) {
        for (Map.Entry<String, List<CallDetail>> e : callsByInstance.entrySet()) {
            List<CallDetail> list = e.getValue();
            if (list.contains(cd)) {
                return e.getKey();
            }
        }
        return null;
    }

    /**
     * Find a message server declaration by name in a given class.
     */
    private MsgsrvDeclaration findMsgsrv(ReactiveClassDeclaration rc, String msgsrvName) {
        for (MsgsrvDeclaration m : rc.getMsgsrvs()) {
            if (m.getName().equals(msgsrvName)) {
                return m;
            }
        }
        return null;
    }

    /**
     * Render an LF reaction in a single place so reaction ordering can be controlled
     * independently from reaction body generation.
     */
    private String renderReaction(String trigger, ReactionContent rContent) {
        StringBuilder sb = new StringBuilder();

        sb.append("    reaction(").append(trigger).append(")");

        if (!rContent.scheduledActions.isEmpty() || !rContent.usedPorts.isEmpty()) {
            sb.append(" -> ");
            List<String> outputs = new ArrayList<>();
            outputs.addAll(rContent.scheduledActions);
            outputs.addAll(rContent.usedPorts);
            for (int i = 0; i < outputs.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(outputs.get(i));
            }
        }

        sb.append(" {=\n");
        sb.append(rContent.code);
        sb.append("    =}\n");

        return sb.toString();
    }

    /**
     * Return the source declaration index of a message server. This is used as a
     * stable tie-breaker when two message servers have the same priority or no priority.
     */
    private int getMsgsrvDeclarationIndex(ReactiveClassDeclaration rc, String msgsrvName) {
        int index = 0;

        for (MsgsrvDeclaration m : rc.getMsgsrvs()) {
            if (m.getName().equals(msgsrvName)) {
                return index;
            }
            index++;
        }

        for (MethodDeclaration m : rc.getSynchMethods()) {
            if (m.getName().equals(msgsrvName)) {
                return index;
            }
            index++;
        }

        return Integer.MAX_VALUE;
    }

    /**
     * Extract DTR @priority from a message server. Lower numbers mean higher priority.
     * If no priority annotation can be found, fall back to Integer.MAX_VALUE so
     * explicitly prioritized message servers are emitted first.
     *
     * This method uses reflection because Rebeca object-model versions expose
     * annotations/priorities using slightly different accessor names.
     */
    private int getMsgsrvPriority(ReactiveClassDeclaration rc, String msgsrvName) {
        MsgsrvDeclaration md = findMsgsrv(rc, msgsrvName);
        if (md == null) {
            return Integer.MAX_VALUE;
        }

        Integer priority = extractPriority(md);
        return priority == null ? Integer.MAX_VALUE : priority;
    }

    private Integer extractPriority(Object obj) {
        if (obj == null) {
            return null;
        }

        // First try direct getter-like methods whose name contains "priority".
        for (java.lang.reflect.Method method : obj.getClass().getMethods()) {
            if (method.getParameterCount() != 0) {
                continue;
            }

            String name = method.getName().toLowerCase(Locale.ROOT);
            if (!name.contains("priority")) {
                continue;
            }

            try {
                Object value = method.invoke(obj);
                Integer parsed = parsePriorityValue(value);
                if (parsed != null) {
                    return parsed;
                }
            } catch (ReflectiveOperationException ignored) {
                // Try other accessors below.
            }
        }

        // Then try annotation accessors such as getAnnotations().
        for (java.lang.reflect.Method method : obj.getClass().getMethods()) {
            if (method.getParameterCount() != 0) {
                continue;
            }

            String name = method.getName().toLowerCase(Locale.ROOT);
            if (!name.contains("annotation")) {
                continue;
            }

            try {
                Object value = method.invoke(obj);
                Integer parsed = parsePriorityValue(value);
                if (parsed != null) {
                    return parsed;
                }
            } catch (ReflectiveOperationException ignored) {
                // Fall through to toString parsing.
            }
        }

        return parsePriorityFromString(obj.toString());
    }

    private Integer parsePriorityValue(Object value) {
        if (value == null) {
            return null;
        }

        if (value instanceof Number n) {
            return n.intValue();
        }

        if (value instanceof Collection<?> collection) {
            for (Object item : collection) {
                Integer parsed = parsePriorityValue(item);
                if (parsed != null) {
                    return parsed;
                }
            }
            return null;
        }

        if (value.getClass().isArray()) {
            int length = java.lang.reflect.Array.getLength(value);
            for (int i = 0; i < length; i++) {
                Integer parsed = parsePriorityValue(java.lang.reflect.Array.get(value, i));
                if (parsed != null) {
                    return parsed;
                }
            }
            return null;
        }

        String text = value.toString();
        Integer fromText = parsePriorityFromString(text);
        if (fromText != null) {
            return fromText;
        }

        boolean looksLikePriorityAnnotation = false;
        for (java.lang.reflect.Method method : value.getClass().getMethods()) {
            if (method.getParameterCount() != 0) {
                continue;
            }

            String methodName = method.getName().toLowerCase(Locale.ROOT);
            if (!(methodName.contains("name") || methodName.contains("key") || methodName.contains("id"))) {
                continue;
            }

            try {
                Object nameValue = method.invoke(value);
                if (nameValue != null && nameValue.toString().equalsIgnoreCase("priority")) {
                    looksLikePriorityAnnotation = true;
                    break;
                }
            } catch (ReflectiveOperationException ignored) {
                // Try the next method.
            }
        }

        if (looksLikePriorityAnnotation) {
            for (java.lang.reflect.Method method : value.getClass().getMethods()) {
                if (method.getParameterCount() != 0) {
                    continue;
                }

                String methodName = method.getName().toLowerCase(Locale.ROOT);
                if (!(methodName.contains("value") || methodName.contains("literal") || methodName.contains("arg"))) {
                    continue;
                }

                try {
                    Object annotationValue = method.invoke(value);
                    Integer parsed = parsePriorityValue(annotationValue);
                    if (parsed != null) {
                        return parsed;
                    }
                } catch (ReflectiveOperationException ignored) {
                    // Try the next method.
                }
            }
        }

        return null;
    }

    private Integer parsePriorityFromString(String text) {
        if (text == null) {
            return null;
        }

        java.util.regex.Matcher matcher = java.util.regex.Pattern
                .compile("(?i)@?priority\\s*\\(?\\s*(\\d+)\\s*\\)?")
                .matcher(text);

        if (matcher.find()) {
            return Integer.parseInt(matcher.group(1));
        }

        matcher = java.util.regex.Pattern
                .compile("(?i)priority\\D+(\\d+)")
                .matcher(text);

        if (matcher.find()) {
            return Integer.parseInt(matcher.group(1));
        }

        return null;
    }

    /**
     * Generate the connection statements in the main reactor for external calls.
     */
    private String generateConnectionStatements(
            Map<String, List<CallDetail>> callsByInstance,
            Map<String, String> instanceToClass
    ) {
        StringBuilder sb = new StringBuilder();
        Set<String> uniqueConnections = new LinkedHashSet<>();

        for (Map.Entry<String, List<CallDetail>> callerEntry : callsByInstance.entrySet()) {
            String callerInst = callerEntry.getKey();
            for (CallDetail cd : callerEntry.getValue()) {
                if (!cd.isInternal) {
                    String calleeInst = cd.externalTargetInstance;
                    String msg = cd.msgName;
                    String outPort = msg + "_to_" + calleeInst + "_from_" + callerInst + "_out";
                    String inPort = msg + "_to_" + calleeInst + "_from_" + callerInst + "_in";

                    String connection = callerInst + "." + outPort + " -> " + calleeInst + "." + inPort;
                    if (cd.afterDelayMs != null && !cd.afterDelayMs.isEmpty()) {
                        connection += " after " + cd.afterDelayMs + "ms";
                    } else {
                        connection += " after 0ms";
                    }
                    uniqueConnections.add(connection);
                }
            }
        }

        for (String c : uniqueConnections) {
            sb.append("    ").append(c).append(";\n");
        }
        return sb.toString();
    }

    /**
     * Build constructor info for a given reactive class (constructor params vs. normal vars).
     */
    private ConstructorInfo buildConstructorInfo(ReactiveClassDeclaration rc) {
        ConstructorInfo cInfo = new ConstructorInfo();
        Map<String, String> statevarNameToType = new HashMap<>();

        // Collect all state var names and types
        if (rc.getStatevars() != null) {
            for (FieldDeclaration fd : rc.getStatevars()) {
                for (VariableDeclarator vd : fd.getVariableDeclarators()) {
                    statevarNameToType.put(vd.getVariableName(), fd.getType().getTypeName());
                }
            }
        }

        ConstructorDeclaration cDec = rc.getConstructors().isEmpty() ? null : rc.getConstructors().get(0);

        // Separate constructor-params from normal state vars
        if (cDec == null) {
            for (var e : statevarNameToType.entrySet()) {
                StateVar sv = new StateVar();
                sv.name = e.getKey();
                sv.type = mapRebecaTypeToLF(e.getValue());
                cInfo.regularStateVars.add(sv);
            }
        } else {
            List<FormalParameterDeclaration> fps = cDec.getFormalParameters();
            Map<String, String> param2stateVar = new HashMap<>();
            parseConstructorBlockForAssignments(cDec.getBlock(), param2stateVar);

            // Store the mapping for later use
            cInfo.paramToStateMapping = param2stateVar;

            // Build set of state variable names for filtering
            Set<String> stateVarNames = new HashSet<>(statevarNameToType.keySet());

            // Filter constructor body: skip param-to-state assignments
            if (cDec.getBlock() != null && cDec.getBlock() instanceof BlockStatement) {
                BlockStatement block = (BlockStatement) cDec.getBlock();
                for (Statement stmt : block.getStatements()) {
                    // Skip assignments like: id = _id
                    if (!isParameterToStateAssignment(stmt, param2stateVar, stateVarNames)) {
                        cInfo.constructorBodyStatements.add(stmt);
                    }
                }
            }

            for (FormalParameterDeclaration fp : fps) {
                String pName = fp.getName();
                String pType = fp.getType().getTypeName();
                String assignedVar = param2stateVar.get(pName);

                if (assignedVar != null && statevarNameToType.containsKey(assignedVar)) {
                    ConstructorParam cp = new ConstructorParam();
                    cp.paramName = pName;
                    cp.stateVarName = assignedVar;
                    cp.type = mapRebecaTypeToLF(pType);
                    cp.defaultValue = getDefaultValueForType(cp.type);
                    cInfo.params.add(cp);
                }
            }

            Set<String> paramVars = cInfo.params.stream()
                    .map(cp -> cp.stateVarName)
                    .collect(Collectors.toSet());

            for (var e : statevarNameToType.entrySet()) {
                if (!paramVars.contains(e.getKey())) {
                    StateVar sv = new StateVar();
                    sv.name = e.getKey();
                    sv.type = mapRebecaTypeToLF(e.getValue());
                    cInfo.regularStateVars.add(sv);
                }
            }
        }

        // Map each msgsrv name to its formal parameters
        for (MsgsrvDeclaration md : rc.getMsgsrvs()) {
            cInfo.msgsrvToParams.put(md.getName(), md.getFormalParameters());
        }

        // Distinguish external vs. internal
        Set<String> internalCalls = new HashSet<>();
        if (cDec != null) {
            analyzeBlockForInternalCalls(cDec.getBlock(), rc.getName(), internalCalls);
        }
        for (MsgsrvDeclaration md : rc.getMsgsrvs()) {
            analyzeBlockForInternalCalls(md.getBlock(), rc.getName(), internalCalls);
        }
        for (MethodDeclaration syncM : rc.getSynchMethods()) {
            analyzeBlockForInternalCalls(syncM.getBlock(), rc.getName(), internalCalls);
        }
        for (MsgsrvDeclaration md : rc.getMsgsrvs()) {
            if (!internalCalls.contains(md.getName())) {
                cInfo.externalMsgsrvsToParams.put(md.getName(), md.getFormalParameters());
            }
        }
        return cInfo;
    }

    /**
     * If the constructor has param->stateVar assignments, capture them.
     */
    private void parseConstructorBlockForAssignments(Statement stmt, Map<String, String> paramToStateVar) {
        if (stmt == null) {
            return;
        }
        if (stmt instanceof BlockStatement bs) {
            for (Statement s : bs.getStatements()) {
                parseConstructorBlockForAssignments(s, paramToStateVar);
            }
        } else if (stmt instanceof ConditionalStatement cs) {
            parseConstructorBlockForAssignments(cs.getStatement(), paramToStateVar);
            if (cs.getElseStatement() != null) {
                parseConstructorBlockForAssignments(cs.getElseStatement(), paramToStateVar);
            }
        } else if (stmt instanceof Expression ex) {
            if (ex instanceof BinaryExpression be && "=".equals(be.getOperator())) {
                if (be.getLeft() instanceof TermPrimary leftTerm && be.getRight() instanceof TermPrimary rightTerm) {
                    paramToStateVar.put(rightTerm.getName(), leftTerm.getName());
                }
            }
        }
    }

    /**
     * Checks if a statement is a parameter-to-state assignment (e.g., id = _id).
     * Returns true if this assignment should be skipped in LF translation.
     */
    private boolean isParameterToStateAssignment(Statement stmt,
                                                 Map<String, String> paramToState,
                                                 Set<String> stateVars) {
        // Only process Expression statements
        if (!(stmt instanceof Expression)) {
            return false;
        }

        Expression expr = (Expression) stmt;

        // Check if it's a binary expression with "=" operator
        if (expr instanceof BinaryExpression be) {
            if ("=".equals(be.getOperator())) {
                // Extract left side (should be state variable)
                String lhs = null;
                if (be.getLeft() instanceof TermPrimary tp) {
                    lhs = tp.getName();
                }

                // Extract right side (should be constructor parameter)
                String rhs = null;
                if (be.getRight() instanceof TermPrimary tp) {
                    rhs = tp.getName();
                }

                // Skip if: stateVar = constructorParam (e.g., id = _id)
                if (lhs != null && rhs != null &&
                        stateVars.contains(lhs) && paramToState.containsKey(rhs)) {
                    return true;
                }
            }
        }

        return false;
    }


    /**
     * Analyze a block to find any `self.foo(...)` calls, marking them as internal.
     */
    private void analyzeBlockForInternalCalls(Statement stmt, String className, Set<String> internalCalls) {
        if (stmt == null) {
            return;
        }
        if (stmt instanceof BlockStatement bs) {
            for (Statement s : bs.getStatements()) {
                analyzeBlockForInternalCalls(s, className, internalCalls);
            }
        } else if (stmt instanceof ConditionalStatement cs) {
            analyzeBlockForInternalCalls(cs.getStatement(), className, internalCalls);
            if (cs.getElseStatement() != null) {
                analyzeBlockForInternalCalls(cs.getElseStatement(), className, internalCalls);
            }
        } else if (stmt instanceof Expression ex) {
            analyzeExpressionForInternalCalls(ex, className, internalCalls);
        }
    }

    /**
     * Recursively check expressions for `self.someMsgSrv(...)` usage.
     */
    private void analyzeExpressionForInternalCalls(Expression expr, String className, Set<String> internalCalls) {
        if (expr == null) {
            return;
        }
        if (expr instanceof DotPrimary dot) {
            analyzeExpressionForInternalCalls(dot.getLeft(), className, internalCalls);
            analyzeExpressionForInternalCalls(dot.getRight(), className, internalCalls);
            if (dot.getLeft() instanceof TermPrimary leftTerm && "self".equals(leftTerm.getName())) {
                if (dot.getRight() instanceof TermPrimary methodTerm) {
                    internalCalls.add(methodTerm.getName());
                }
            }
        } else if (expr instanceof UnaryExpression ue) {
            analyzeExpressionForInternalCalls(ue.getExpression(), className, internalCalls);
        } else if (expr instanceof BinaryExpression be) {
            analyzeExpressionForInternalCalls(be.getLeft(), className, internalCalls);
            analyzeExpressionForInternalCalls(be.getRight(), className, internalCalls);
        }
    }

    /**
     * Build a map from rebec instance name to its class name.
     */
    private Map<String, String> buildInstanceToClassMap() {
        Map<String, String> map = new HashMap<>();
        MainDeclaration mainDecl = rebecaModel.getRebecaCode().getMainDeclaration();
        if (mainDecl != null) {
            for (MainRebecDefinition mrd : mainDecl.getMainRebecDefinition()) {
                map.put(mrd.getName(), mrd.getType().getTypeName());
            }
        }
        return map;
    }

    /**
     * For each reactive class, gather the known rebecs (fields).
     */
    private Map<String, List<String>> buildClassToKnownRebecsMap() {
        Map<String, List<String>> map = new HashMap<>();
        for (ReactiveClassDeclaration rc : classes) {
            List<String> knowns = new ArrayList<>();
            if (rc.getKnownRebecs() != null) {
                for (FieldDeclaration fd : rc.getKnownRebecs()) {
                    for (VariableDeclarator vd : fd.getVariableDeclarators()) {
                        knowns.add(vd.getVariableName());
                    }
                }
            }
            map.put(rc.getName(), knowns);
        }
        return map;
    }

    /**
     * Determine which rebecs are assigned to each instance's known fields.
     */
    private Map<String, List<String>> buildInstanceKnownRebecsMap(Map<String, String> instanceToClass) {
        Map<String, List<String>> res = new HashMap<>();
        MainDeclaration md = rebecaModel.getRebecaCode().getMainDeclaration();
        if (md == null) {
            return res;
        }

        Map<String, List<String>> classToKnownFields = new HashMap<>();
        for (ReactiveClassDeclaration rc : classes) {
            List<String> knownVars = new ArrayList<>();
            if (rc.getKnownRebecs() != null) {
                for (FieldDeclaration fd : rc.getKnownRebecs()) {
                    for (VariableDeclarator vd : fd.getVariableDeclarators()) {
                        knownVars.add(vd.getVariableName());
                    }
                }
            }
            classToKnownFields.put(rc.getName(), knownVars);
        }

        for (MainRebecDefinition def : md.getMainRebecDefinition()) {
            String instName = def.getName();
            String clsName = def.getType().getTypeName();
            List<String> fields = classToKnownFields.getOrDefault(clsName, Collections.emptyList());
            List<Expression> bindings = def.getBindings();
            List<String> actualKnown = new ArrayList<>();

            if (bindings != null && bindings.size() == fields.size()) {
                for (Expression e : bindings) {
                    if (e instanceof TermPrimary tp) {
                        actualKnown.add(tp.getName());
                    }
                }
            }
            res.put(instName, actualKnown);
        }
        return res;
    }

    /**
     * Gather internal/external calls across the model and fill callsByInstance.
     */
    private void analyzeAllCalls(
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance,
            Map<String, List<String>> classToKnownRebecs,
            Map<String, List<String>> instanceKnownRebecs
    ) {
        for (ReactiveClassDeclaration rc : classes) {
            String cName = rc.getName();
            for (ConstructorDeclaration cDec : rc.getConstructors()) {
                parseBlockStatement(
                        cDec.getBlock(),
                        cName,
                        instanceToClass,
                        callsByInstance,
                        classToKnownRebecs,
                        instanceKnownRebecs,
                        ""
                );
            }
            for (MsgsrvDeclaration md : rc.getMsgsrvs()) {
                parseBlockStatement(
                        md.getBlock(),
                        cName,
                        instanceToClass,
                        callsByInstance,
                        classToKnownRebecs,
                        instanceKnownRebecs,
                        md.getName()
                );
            }
            for (MethodDeclaration synM : rc.getSynchMethods()) {
                parseBlockStatement(
                        synM.getBlock(),
                        cName,
                        instanceToClass,
                        callsByInstance,
                        classToKnownRebecs,
                        instanceKnownRebecs,
                        synM.getName()
                );
            }
        }
    }

    /**
     * Parse a Rebeca statement recursively to detect calls and populate callsByInstance.
     */
    private void parseBlockStatement(
            Statement stmt,
            String currentClass,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance,
            Map<String, List<String>> classToKnownRebecs,
            Map<String, List<String>> instanceKnownRebecs,
            String currentMsgsrvName
    ) {
        if (stmt == null) {
            return;
        }

        if (stmt instanceof BlockStatement bs) {
            for (Statement s : bs.getStatements()) {
                parseBlockStatement(
                        s,
                        currentClass,
                        instanceToClass,
                        callsByInstance,
                        classToKnownRebecs,
                        instanceKnownRebecs,
                        currentMsgsrvName
                );
            }
        } else if (stmt instanceof ConditionalStatement cs) {
            parseBlockStatement(
                    cs.getStatement(),
                    currentClass,
                    instanceToClass,
                    callsByInstance,
                    classToKnownRebecs,
                    instanceKnownRebecs,
                    currentMsgsrvName
            );
            if (cs.getElseStatement() != null) {
                parseBlockStatement(
                        cs.getElseStatement(),
                        currentClass,
                        instanceToClass,
                        callsByInstance,
                        classToKnownRebecs,
                        instanceKnownRebecs,
                        currentMsgsrvName
                );
            }
        } else if (stmt instanceof Expression ex) {
            parseExpression(
                    ex,
                    currentClass,
                    instanceToClass,
                    callsByInstance,
                    classToKnownRebecs,
                    instanceKnownRebecs,
                    currentMsgsrvName
            );
        }
    }

    /**
     * Parse a Rebeca expression to detect calls and store them in callsByInstance.
     */
    private void parseExpression(
            Expression expr,
            String currentClass,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance,
            Map<String, List<String>> classToKnownRebecs,
            Map<String, List<String>> instanceKnownRebecs,
            String currentMsgsrvName
    ) {
        if (expr == null) {
            return;
        }

        if (expr instanceof DotPrimary dot) {
            parseExpression(dot.getLeft(), currentClass, instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs, currentMsgsrvName);
            parseExpression(dot.getRight(), currentClass, instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs, currentMsgsrvName);

            if (dot.getRight() instanceof TermPrimary methodTerm) {
                String methodName = methodTerm.getName();
                ParentSuffixPrimary psp = methodTerm.getParentSuffixPrimary();
                List<Expression> argList = (psp == null) ? Collections.emptyList() : psp.getArguments();

                // Timed Rebeca 'after' handling
                String afterDelayMs = null;
                if (psp instanceof TimedRebecaParentSuffixPrimary timedPSP) {
                    Expression afterExpr = timedPSP.getAfterExpression();
                    if (afterExpr != null) {
                        afterDelayMs = expressionToString(afterExpr, "int", "0");
                        for (Map.Entry<String, String> entry : envVariables.entrySet()) {
                            afterDelayMs = afterDelayMs.replace(entry.getKey(), entry.getValue());
                        }
                    }
                }

                // self.method(...)
                if (dot.getLeft() instanceof TermPrimary leftTerm && "self".equals(leftTerm.getName())) {
                    for (Map.Entry<String, String> e : instanceToClass.entrySet()) {
                        if (e.getValue().equals(currentClass)) {
                            CallDetail cd = new CallDetail(methodName, true, "");
                            cd.arguments = argList;
                            cd.callerMsgsrvName = currentMsgsrvName;
                            cd.calleeClass = currentClass;
                            if (afterDelayMs != null) {
                                cd.afterDelayMs = afterDelayMs;
                            }
                            callsByInstance.get(e.getKey()).add(cd);
                        }
                    }
                    // knownRebec.method(...)
                } else if (dot.getLeft() instanceof TermPrimary knownField) {
                    if (classToKnownRebecs
                            .getOrDefault(currentClass, Collections.emptyList())
                            .contains(knownField.getName())) {
                        for (Map.Entry<String, String> e : instanceToClass.entrySet()) {
                            if (!e.getValue().equals(currentClass)) {
                                continue;
                            }
                            String callerInstance = e.getKey();
                            List<String> knownList = instanceKnownRebecs.getOrDefault(callerInstance, Collections.emptyList());
                            int idx = classToKnownRebecs.get(currentClass).indexOf(knownField.getName());
                            if (idx >= 0 && idx < knownList.size()) {
                                String targetInstance = knownList.get(idx);
                                String calleeCls = instanceToClass.get(targetInstance);

                                CallDetail cd = new CallDetail(methodName, false, targetInstance);
                                cd.arguments = argList;
                                cd.callerMsgsrvName = currentMsgsrvName;
                                cd.calleeClass = calleeCls;
                                if (afterDelayMs != null) {
                                    cd.afterDelayMs = afterDelayMs;
                                }
                                callsByInstance.get(callerInstance).add(cd);
                            }
                        }
                    }
                }
            }
        } else if (expr instanceof UnaryExpression ue) {
            parseExpression(ue.getExpression(), currentClass, instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs, currentMsgsrvName);
        } else if (expr instanceof BinaryExpression be) {
            parseExpression(be.getLeft(), currentClass, instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs, currentMsgsrvName);
            parseExpression(be.getRight(), currentClass, instanceToClass, callsByInstance, classToKnownRebecs, instanceKnownRebecs, currentMsgsrvName);
        }
    }


    /* ----------------------------------------------------------------------
     * Expression/Type Utilities
     * ----------------------------------------------------------------------
     */

    /**
     * Transform a Rebeca Expression into a string for insertion into generated code.
     */
    private String transformExpression(
            Expression expr,
            String msgsrvName,
            ConstructorInfo cInfo,
            Map<String, String> externalParamMapping
    ) {
        if (expr == null) {
            return "";
        }
        if (expr instanceof Literal lit) {
            return lit.getLiteralValue();
        }
        if (expr instanceof TermPrimary tp) {
            String raw = tp.getName();

            // If 'raw' is an environment variable, inline its literal value with a comment.

            if (envVariables.containsKey(raw)) {
                return envVariables.get(raw) + " /* env variable " + raw + " replaced */";
            }


            // Replace constructor parameter names with state variable names
            // Example: _id -> id
            if (cInfo != null && cInfo.paramToStateMapping != null &&
                    cInfo.paramToStateMapping.containsKey(raw)) {
                raw = cInfo.paramToStateMapping.get(raw);
            }

            if (externalParamMapping != null && externalParamMapping.containsKey(raw)) {
                return externalParamMapping.get(raw);
            }
            return raw;
        }

        if (expr instanceof BinaryExpression be) {
            String op = be.getOperator();

            if ("==".equals(op) || "!=".equals(op)) {
                String senderComparison = transformSenderComparison(
                        be.getLeft(),
                        be.getRight(),
                        op,
                        externalParamMapping
                );

                if (senderComparison != null) {
                    return senderComparison;
                }
            }

            String l = transformExpression(be.getLeft(), msgsrvName, cInfo, externalParamMapping);
            String r = transformExpression(be.getRight(), msgsrvName, cInfo, externalParamMapping);
            return l + " " + op + " " + r;
        }
        if (expr instanceof UnaryExpression ue) {
            String sub = transformExpression(ue.getExpression(), msgsrvName, cInfo, externalParamMapping);
            return ue.getOperator() + sub;
        }
        if (expr instanceof DotPrimary dp) {
            String left = transformExpression(dp.getLeft(), msgsrvName, cInfo, externalParamMapping);
            String right = transformExpression(dp.getRight(), msgsrvName, cInfo, externalParamMapping);
            if (left.isEmpty()) {
                return right;
            }
            return left + "." + right;
        }
        return "";
    }

    /**
     * Build sender/known-rebec context for a generated external input-port reaction.
     *
     * The generated input port name has the form:
     *     msg_to_TARGET_from_SENDER_in
     *
     * For example:
     *     permit_to_phil0_from_fork0_in
     *
     * In that reaction, sender is fork0 and receiver is phil0. We use the receiver's
     * known-rebec bindings to decide whether sender == forkL, sender == philL, etc.
     */
    private Map<String, String> buildSenderContextForExternalPort(
            String receiverClassName,
            String portName,
            Map<String, String> instanceToClass
    ) {
        Map<String, String> context = new HashMap<>();

        String[] endpoints = parseExternalInputPortName(portName);
        if (endpoints == null) {
            return context;
        }

        String receiverInstance = endpoints[0];
        String senderInstance = endpoints[1];

        context.put(RECEIVER_INSTANCE_KEY, receiverInstance);
        context.put(SENDER_INSTANCE_KEY, senderInstance);

        Map<String, List<String>> classToKnownRebecs = buildClassToKnownRebecsMap();
        Map<String, List<String>> instanceKnownRebecs = buildInstanceKnownRebecsMap(instanceToClass);

        List<String> knownFieldNames =
                classToKnownRebecs.getOrDefault(receiverClassName, Collections.emptyList());

        List<String> knownInstances =
                instanceKnownRebecs.getOrDefault(receiverInstance, Collections.emptyList());

        int count = Math.min(knownFieldNames.size(), knownInstances.size());
        for (int i = 0; i < count; i++) {
            context.put(
                    KNOWN_REBEC_INSTANCE_PREFIX + knownFieldNames.get(i),
                    knownInstances.get(i)
            );
        }

        return context;
    }

    /**
     * Parse generated external input-port names:
     *     msg_to_TARGET_from_SENDER_in
     *
     * Returns [TARGET, SENDER], or null if the name does not match.
     */
    private String[] parseExternalInputPortName(String portName) {
        if (portName == null || !portName.endsWith("_in")) {
            return null;
        }

        int fromIdx = portName.lastIndexOf("_from_");
        if (fromIdx < 0) {
            return null;
        }

        int toIdx = portName.lastIndexOf("_to_", fromIdx - 1);
        if (toIdx < 0) {
            return null;
        }

        String receiverInstance = portName.substring(toIdx + "_to_".length(), fromIdx);
        String senderInstance = portName.substring(
                fromIdx + "_from_".length(),
                portName.length() - "_in".length()
        );

        if (receiverInstance.isEmpty() || senderInstance.isEmpty()) {
            return null;
        }

        return new String[]{receiverInstance, senderInstance};
    }

    /**
     * Reduce sender comparisons to true/false when possible.
     *
     * Examples:
     *     sender == forkL
     *     sender != philR
     */
    private String transformSenderComparison(
            Expression left,
            Expression right,
            String op,
            Map<String, String> context
    ) {
        String leftName = getSimpleTermName(left);
        String rightName = getSimpleTermName(right);

        if (leftName == null || rightName == null) {
            return null;
        }

        Boolean equalsResult = null;

        if ("sender".equals(leftName)) {
            equalsResult = isSenderEqualToKnownRebec(rightName, context);
        } else if ("sender".equals(rightName)) {
            equalsResult = isSenderEqualToKnownRebec(leftName, context);
        }

        if (equalsResult == null) {
            return null;
        }

        if ("!=".equals(op)) {
            equalsResult = !equalsResult;
        }

        return equalsResult ? "true" : "false";
    }

    private String getSimpleTermName(Expression expr) {
        if (expr instanceof TermPrimary tp) {
            return tp.getName();
        }
        return null;
    }

    private Boolean isSenderEqualToKnownRebec(String knownRebecFieldName, Map<String, String> context) {
        if (context == null) {
            return null;
        }

        String senderInstance = context.get(SENDER_INSTANCE_KEY);
        if (senderInstance == null) {
            return null;
        }

        String knownInstance = context.get(KNOWN_REBEC_INSTANCE_PREFIX + knownRebecFieldName);
        if (knownInstance == null) {
            return null;
        }

        return senderInstance.equals(knownInstance);
    }

    /**
     * Map a Rebeca type name to the Lingua Franca/C++ equivalent.
     */
    private String mapRebecaTypeToLF(String rebType) {
        return switch (rebType) {
            case "boolean" -> "bool";
            case "int", "byte" -> "int";
            case "double" -> "double";
            default -> rebType;
        };
    }

    /**
     * Provide a default value for a given type (bool->false, int->0, etc.).
     */
    private String getDefaultValueForType(String lfType) {
        return switch (lfType) {
            case "bool" -> "false";
            case "double" -> "0.0";
            default -> "0";
        };
    }

    /**
     * Convert a Rebeca expression (used as a constructor argument, or 'after') to string.
     */
    private String expressionToString(Expression expr, String lfType, String fallback) {
        if (expr == null) {
            return fallback;
        }
        if (expr instanceof Literal lit) {
            return lit.getLiteralValue();
        }
        if (expr instanceof TermPrimary tp) {
            return tp.getName();
        }
        if (expr instanceof BinaryExpression be) {
            String leftStr = expressionToString(be.getLeft(), lfType, fallback);
            String rightStr = expressionToString(be.getRight(), lfType, fallback);
            return leftStr + " " + be.getOperator() + " " + rightStr;
        }
        return fallback;
    }

    /**
     * Retrieve constructor info for a given callee class (non-optimized approach).
     */
    private ConstructorInfo cInfoFor(String cls, Map<String, String> inst2cls) {
        for (ReactiveClassDeclaration rcd : classes) {
            if (rcd.getName().equals(cls)) {
                // Build fresh each time to avoid partial state caching
                return buildConstructorInfo(rcd);
            }
        }
        return new ConstructorInfo();
    }

    /**
     * Generate the reaction body for an unused msgsrv (for documentation purposes).
     */
    private ReactionContent generateUnusedMsgsrvReactionBody(
            MsgsrvDeclaration unusedMsgSrvDecl,
            String className,
            ConstructorInfo cInfo,
            Map<String, String> instanceToClass,
            Map<String, List<CallDetail>> callsByInstance
    ) {
        ReactionContent rc = new ReactionContent();
        if (unusedMsgSrvDecl == null || unusedMsgSrvDecl.getBlock() == null) {
            return rc;
        }

        // Unused msgsrvs have no triggering inputs. If their body refers to formal
        // parameters, map those parameters to default values so we do not emit
        // obsolete param_for_msgsrv state-variable references.
        Map<String, String> unusedParamMapping = new HashMap<>();
        List<FormalParameterDeclaration> fps =
                cInfo.msgsrvToParams.getOrDefault(unusedMsgSrvDecl.getName(), Collections.emptyList());

        for (FormalParameterDeclaration fp : fps) {
            String lfType = mapRebecaTypeToLF(fp.getType().getTypeName());
            unusedParamMapping.put(fp.getName(), getDefaultValueForType(lfType));
        }

        rc.code = parseBlockStatementInline(
                unusedMsgSrvDecl.getBlock(),
                className,
                unusedMsgSrvDecl.getName(),
                cInfo,
                instanceToClass,
                callsByInstance,
                rc.scheduledActions,
                rc.usedPorts,
                unusedParamMapping
        );
        return rc;
    }
}
